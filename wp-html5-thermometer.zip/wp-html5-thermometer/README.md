wpch_thermometer_plugin
=======================
The “Progress Indicator Thermometer” plugin uses a simple shortcode to display an aesthetically pleasing thermometer on your WordPress page, post or sidebar to indicate the progress your fund-raising and charity activities.

The plugin allows the user to set a fundraising target and update a “current total” amount. The user interface is extremely simple and easy to use. Easily update titles, change currency or update the amount of money raised at any given time.

To use the thermometer simply download, install and activate the plugin, then add the shortcode (available in the user interface once installed) to your post, page or sidebar.

Tags: charity, donate, donation, fundraising, indicator, meter, money, non-profit, progress, thermometer
