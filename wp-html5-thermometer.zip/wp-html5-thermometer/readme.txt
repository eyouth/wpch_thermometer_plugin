=== Charity-thermometer ===
Contributors: eyouth.ace
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=33HE6UC8VRNRU&lc=PH&item_name=Charity%20Thermometer&item_number=charterm¤cy_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted
Tags: charity, donate, donation, fundraising, indicator, meter, money, non-profit, progress, thermometer
Requires at least: 3.5
Tested up to: 3.5.1
Stable tag: charity, donate, donation, fundraising, indicator, meter, money, non-profit, progress, thermometer
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The “Progress Indicator Thermometer” plugin uses a simple shortcode to display an aesthetically pleasing thermometer on your WordPress page, post or sidebar to indicate the progress your fund-raising and charity activities.

== Description ==

The “Progress Indicator Thermometer” plugin uses a simple shortcode to display an aesthetically pleasing thermometer on your WordPress page, post or sidebar to indicate the progress your fund-raising and charity activities.

The plugin allows the user to set a fundraising target and update a “current total” amount. The user interface is extremely simple and easy to use. Easily update titles, change currency or update the amount of money raised at any given time.

To use the thermometer simply download, install and activate the plugin, then add the shortcode (available in the user interface once installed) to your post, page or sidebar.

== Installation ==

1. Upload wp-html5-thermometer folder to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==

= A question that someone might have =

An answer to that question.

== Screenshots ==

1. https://github.com/eyouth/wpch_thermometer_plugin/blob/master/css/images/thermometer_sc.jpg
2. https://github.com/eyouth/wpch_thermometer_plugin/blob/master/css/images/thermometer_sc2.jpg

== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==
